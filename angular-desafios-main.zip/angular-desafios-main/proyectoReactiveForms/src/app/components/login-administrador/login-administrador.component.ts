import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-administrador',
  templateUrl: './login-administrador.component.html',
  styleUrls: ['./login-administrador.component.css']
})
export class LoginAdministradorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
