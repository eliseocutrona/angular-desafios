import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-estudiante',
  templateUrl: './login-estudiante.component.html',
  styleUrls: ['./login-estudiante.component.css']
})
export class LoginEstudianteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
