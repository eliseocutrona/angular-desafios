export interface Curso{
    nombre: string;
    comision: string;
    profesor: string;
}