export interface Estudiante{
    nombre: string;
    edad: number;
    estaActivo: boolean;
}