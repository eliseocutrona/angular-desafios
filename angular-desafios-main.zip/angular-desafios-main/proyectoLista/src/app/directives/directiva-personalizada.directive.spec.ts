import { DirectivaPersonalizadaDirective } from './directiva-personalizada.directive';

describe('DirectivaPersonalizadaDirective', () => {
  it('should create an instance', () => {
    const directive = new DirectivaPersonalizadaDirective();
    expect(directive).toBeTruthy();
  });
});
